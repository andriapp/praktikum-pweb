<!DOCTYPE html>
<html>
<head>
  <title>Semua Data Sekolah</title>
</head>
<body>
<h1 align="center">Semua Data Sekolah</h1>

<style type="text/css">
  table {
    border-spacing: 0;
    border-collapse: collapse;
    margin: 10px auto 0px auto;
    
}
</style>

<table border='1'>
    <tr>
      <th>Nomor</th>
      <th>NPSN</th>
      <th>Nama Skolah</th>
      <th>Alamat</th>
      <th>Desa/Kelurahan</th>
      <th>Kecamatan</th>
      <th>Kab/Kota</th>
      <th>Jenjang</th>
      <th>Status</th>
      <th>Akreditasi</th>
      <th>Telepon</th>
    </tr>


<?php

include "koneksi.php";
$sql = "SELECT*FROM sekolah";
$result = mysql_query($sql);
$no=1;

        while ($hasil = mysql_fetch_array($result)) { ?>
        <tr>
        <td><?php echo $no++?></td>
        <td><?php echo $hasil[0]?></td>
        <td><?php echo $hasil[1]?></td>
        <td><?php echo $hasil[2]?></td>
        <td><?php echo $hasil[3]?></td>
        <td><?php echo $hasil[4]?></td>
        <td><?php echo $hasil[5]?></td>
        <td><?php echo $hasil[6]?></td>
        <td><?php echo $hasil[7]?></td>
        <td><?php echo $hasil[8]?></td>
        <td><?php echo $hasil[9]?></td>
        <?php } ?>

</body>
</html>