<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sekolah";

// Create connection
mysql_connect($servername, $username, $password, $dbname);
mysql_select_db($dbname);
// Check connection
?>