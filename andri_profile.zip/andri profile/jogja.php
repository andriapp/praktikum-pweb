<!DOCTYPE html>
<html>
<head>
	<title>Sekolah SD/MI Di Kota Jogja</title>
</head>
<body>
<h1 align="center"> Sekolah SD/MI Di Kota Jogja</h1>
<style type="text/css">
  table {
    border-spacing: 0;
    border-collapse: collapse;
    margin: 10px auto 0px auto;
    
}
</style>

<table border='1'>
    <tr>
      <th>Nomor</th>
      <th>NPSN</th>
      <th>Nama Sekolah</th>
      <th>Alamat</th>
    </tr>


<?php
include"koneksi.php";
$sql=mysql_query("SELECT NPSN,Nama,Alamat FROM sekolah WHERE Kab_Kota='Kota Yogyakarta'");
$no=1;
while ($hasil = mysql_fetch_array($sql)) { ?>
        <tr>
        <td><?php echo $no++?></td>
        <td><?php echo $hasil[0]?></td>
        <td><?php echo $hasil[1]?></td>
        <td><?php echo $hasil[2]?></td>
        <?php } ?>

</body>
</html>